package testProject;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test7 {

	public static void main(String[] args) {
		
		
	try {
		WebDriver fan;
		fan=new ChromeDriver();
		fan.get("https://www.flipkart.com/");
		File src2=((TakesScreenshot)fan).getScreenshotAs(OutputType.FILE);
		File src1=new File("./div");
		FileUtils.copyFile(src2,src1);
	} catch (WebDriverException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		// TODO Auto-generated method stub

	}

}

