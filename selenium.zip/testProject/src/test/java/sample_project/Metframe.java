package sample_project;


public class Metframe extends Framework

{
	public static void main(String[] args)
	{
	
	browser("Chrome");
	application("https://accounts.google.com/signup");
	typeIn("//input[@id='firstName']","test");
	clickIn("//input[@type='checkbox']");		
			
		
		}		
		// TODO Auto-generated method stub

	

}
