package sample_project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Framework
{
	static WebDriver driver;
	
	public static void browser(String browserValue)
	{
	try 
		{
		
		switch(browserValue) {
		
		case "chrome":
			
		driver=new ChromeDriver();
		break;
		case "edge":
		
		driver=new FirefoxDriver();
		
		break;
			
		default:
		break;
		
		
			// TODO Auto-generated method stub

		}

		
	}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	public static void application(String url)
	{
		try {
			driver.get(url);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	public static void typeIn(String xpathValue,String dataValue)
	{
		try {
			driver.findElement(By.xpath(xpathValue)).sendKeys(dataValue);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void clickIn(String xpathValue)
	{
		try {
			driver.findElement(By.xpath(xpathValue)).click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public static void clearAll(String xpathValue)
	{
		try {
			driver.findElement(By.xpath(xpathValue)).clear();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	
	

}





