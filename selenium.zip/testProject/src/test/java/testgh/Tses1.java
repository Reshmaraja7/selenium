package testgh;

import org.testng.annotations.Test;

public class Tses1 {

	
	
	@Test(priority=2)
	public void test01()
	{
		System.out.println("login");	
		
	}
	@Test(enabled = false)
	public void test02()
	
	{
		System.out.println("logout");
	}
@Test
public void test03()
	
	{
		System.out.println("log");
	}

	
}


