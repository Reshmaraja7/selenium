package testng;

public class Tses2 {

}
